# hello, django.contrib.staticfiles!
