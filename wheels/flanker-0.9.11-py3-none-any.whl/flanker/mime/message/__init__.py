from flanker.mime.message.scanner import ContentType
