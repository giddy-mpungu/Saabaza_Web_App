Authors & Contributors
======================

* Matt Croydon;
* Mikhail Korobov;
* Pawel Tomasiewicz;
* Steve Jones;
* Petr Dlouhý;
* @ivirabyan.
