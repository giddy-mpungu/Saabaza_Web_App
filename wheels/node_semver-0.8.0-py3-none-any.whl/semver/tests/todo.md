https://github.com/npm/node-semver/blob/master/test/index.js

- diff versions test
- impement min_satisfying
- implement intersects
